# HG002 Variant Calling Pipeline

This repository contains a Nextflow pipeline for variant calling using:

- Minimap2 (alignment)
- Samtools (sorting & indexing)
- DeepVariant (variant calling)

## Requirements

- Nextflow
- Singularity / Docker

## Run

```bash
nextflow run main.nf -resume
```

## Benchmarking

Benchmarking is performed using hap.py against GIAB truth set.
