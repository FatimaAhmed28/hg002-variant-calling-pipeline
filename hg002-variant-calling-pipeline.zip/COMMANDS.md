# Commands Documentation

## Run Pipeline

nextflow run main.nf -resume

## Benchmark with hap.py

hap.py truth.vcf.gz query.vcf.gz   -f confident_regions.bed   -r GRCh38.fa   -o output_prefix
